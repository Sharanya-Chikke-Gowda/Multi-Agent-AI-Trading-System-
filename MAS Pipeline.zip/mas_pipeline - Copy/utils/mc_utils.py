# utils/mc_utils.py

import numpy as np

# -----------------------------------------
# 1) Robust shrinkage covariance
# -----------------------------------------
def shrinkage_covariance(S: np.ndarray, shrink=0.1) -> np.ndarray:
    S = np.asarray(S)

    if S.ndim == 0:          # scalar var
        S = np.array([[float(S)]])
    elif S.ndim == 1:        # variance vector
        S = np.diag(S)
    elif S.ndim == 2:
        pass
    else:
        raise ValueError("Invalid covariance dimension")

    dim = S.shape[0]
    avg_var = float(np.trace(S)) / dim
    F = np.eye(dim) * avg_var
    shrink = max(0.0, min(1.0, shrink))

    return (1 - shrink) * S + shrink * F


# -----------------------------------------
# 2) GBM multivariate simulation
# -----------------------------------------
def gbm_batch_simulate(batch, horizon, mu_daily, cov_daily, rng=None):
    if rng is None:
        rng = np.random.default_rng()

    mu_daily = np.asarray(mu_daily)
    cov_daily = np.asarray(cov_daily)

    if np.isscalar(cov_daily):
        cov_daily = np.array([[float(cov_daily)]])
    elif cov_daily.ndim == 1:
        cov_daily = np.diag(cov_daily)

    N = len(mu_daily)

    Z = rng.normal(size=(batch * horizon, N))
    chol = np.linalg.cholesky(cov_daily + 1e-12*np.eye(N))

    shocks = (Z @ chol.T).reshape(batch, horizon, N)
    drift = mu_daily - 0.5 * np.diag(cov_daily)

    log_returns = shocks + drift
    cum_log = np.sum(log_returns, axis=1)

    return np.exp(cum_log) - 1


# -----------------------------------------
# 3) Student-t correlated shocks
# -----------------------------------------
def student_t_shocks(batch, horizon, N, df, cov, rng=None):
    if rng is None:
        rng = np.random.default_rng()

    Z = rng.normal(size=(batch*horizon, N))

    if df > 2:
        g = rng.gamma(df/2, 2/df, size=(batch*horizon,))
        scale = np.sqrt(df/(df-2))
        t_samples = Z / np.sqrt(g)[:,None] * scale
    else:
        t_samples = Z

    cov = np.asarray(cov)
    if np.isscalar(cov):
        cov = np.array([[float(cov)]])
    elif cov.ndim == 1:
        cov = np.diag(cov)

    chol = np.linalg.cholesky(cov + 1e-12*np.eye(cov.shape[0]))

    return (t_samples @ chol.T).reshape(batch, horizon, cov.shape[0])


# -----------------------------------------
# 4) Block bootstrap
# -----------------------------------------
def block_bootstrap_returns(returns, horizon, sims, block_size=5, rng=None):
    if rng is None:
        rng = np.random.default_rng()

    T, N = returns.shape
    out = np.empty((sims, horizon, N))

    for i in range(sims):
        seq = []
        while len(seq) < horizon:
            start = rng.integers(0, max(1, T - block_size))
            seq.append(returns[start:start+block_size])
        seq = np.vstack(seq)[:horizon]
        out[i] = seq

    return np.prod(1 + out, axis=1) - 1
