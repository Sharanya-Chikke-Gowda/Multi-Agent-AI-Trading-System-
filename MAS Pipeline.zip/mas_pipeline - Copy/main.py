# main.py — FULL UPDATED MAS PIPELINE
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import sys
import warnings
warnings.filterwarnings("ignore")

from core.state import MASState
from core.langgraph import LangGraph

# ==== Agents ====
from agents.data_agent import DataAgent
from agents.sentiment_agent import SentimentAgent
from agents.prediction_agent import PredictionAgent
from agents.risk_agent import RiskAgent
from agents.portfolio_agent import PortfolioAgent
from agents.backtester_agent import BacktesterAgent
from agents.report_agent import ReportAgent


# -------------------------------------------------------------
# USER INPUT
# -------------------------------------------------------------
print("\n============================")
print("      MAS PIPELINE RUN      ")
print("============================")

selected_ticker = input("Enter stock ticker (e.g., TSLA, AAPL, WMT): ").strip().upper()

print(f"Selected Ticker: {selected_ticker}")


# -------------------------------------------------------------
# INITIALIZE STATE
# -------------------------------------------------------------
state = MASState()
state.data["selected_ticker"] = selected_ticker

# -------------------------------------------------------------
# BUILD MAS PIPELINE GRAPH
# -------------------------------------------------------------
pipeline = LangGraph()

# 1. DATA AGENT
pipeline.add(lambda s: DataAgent(
    s,
    tickers=[selected_ticker],
    context_tickers=["SPY", "QQQ", "VIX", "TNX"],
    start="2010-01-01",
    end=None
))

# 2. SENTIMENT AGENT
pipeline.add(SentimentAgent)

# 3. LSTM/ML PREDICTION AGENT
pipeline.add(lambda s: PredictionAgent(
    s,
    window=60,
    retrain=True    # allow training on the fly
))

# 4. RISK AGENT (advanced MC)
pipeline.add(lambda s: RiskAgent(
    s,
    assets=[selected_ticker],

    # ★ Use smoother Monte Carlo
    method="gbm_mv",

    mc_sims=20000,
    horizon_days=5,

    # For Student-t method:
    # method="studentt_mv",
    # student_t_df=10,

    batch_size=2000
))

# 5. PORTFOLIO DECISION AGENT (allow short + dynamic sizing)
pipeline.add(PortfolioAgent)

# 6. BACKTESTING / SIMULATION
pipeline.add(BacktesterAgent)

# 7. REPORTING (PDF, metrics, charts)
pipeline.add(ReportAgent)


# -------------------------------------------------------------
# RUN PIPELINE
# -------------------------------------------------------------
print("\nRunning MAS Pipeline...")
pipeline.run(state)

print("\n==============================================")
print(" MAS Pipeline Completed. Check 'reports/' dir ")
print("==============================================")
