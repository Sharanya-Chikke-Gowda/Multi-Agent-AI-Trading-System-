class LangGraph:
    def __init__(self):
        self.nodes = []
    def add(self, fn):
        self.nodes.append(fn)
    def run(self, state):
        for fn in self.nodes:
            fn(state)
