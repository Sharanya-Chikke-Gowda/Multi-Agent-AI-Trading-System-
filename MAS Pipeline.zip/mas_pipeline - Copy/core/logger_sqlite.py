import sqlite3
from datetime import datetime
import json

class SQLiteLogger:
    def __init__(self, db_path="mas_logs.db"):
        self.conn = sqlite3.connect(db_path)
        self.create_tables()

    def create_tables(self):
        cur = self.conn.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY, timestamp TEXT, agent TEXT, message TEXT)")
        cur.execute("CREATE TABLE IF NOT EXISTS metrics (id INTEGER PRIMARY KEY, timestamp TEXT, name TEXT, value TEXT)")
        cur.execute("CREATE TABLE IF NOT EXISTS mc_runs (id INTEGER PRIMARY KEY, timestamp TEXT, method TEXT, sims INTEGER, horizon INTEGER, summary TEXT)")
        self.conn.commit()

    def log(self, agent, msg):
        cur = self.conn.cursor()
        cur.execute("INSERT INTO logs VALUES(NULL,?,?,?)",(datetime.utcnow().isoformat(), agent, msg))
        self.conn.commit()

    def metric(self, name, val):
        cur = self.conn.cursor()
        cur.execute("INSERT INTO metrics VALUES(NULL,?,?,?)",(datetime.utcnow().isoformat(), name, str(val)))
        self.conn.commit()

    def mc(self, method, sims, horizon, summary):
        cur = self.conn.cursor()
        cur.execute("INSERT INTO mc_runs VALUES(NULL,?,?,?,?,?)",(datetime.utcnow().isoformat(), method, sims, horizon, json.dumps(summary)))
        self.conn.commit()

sqlite_logger = SQLiteLogger()
