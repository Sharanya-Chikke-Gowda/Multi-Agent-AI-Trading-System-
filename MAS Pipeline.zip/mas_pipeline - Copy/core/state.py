# core/state.py

import datetime

class MASState:
    """
    Global MAS State object.
    Stores:
        - Data (price, sentiment, features)
        - Model results (predictions, VaR, signals)
        - Logs (agent audit trail)
    """

    def __init__(self):
        self.data = {}       # All agent-loaded data (prices, sentiment, features)
        self.results = {}    # Model outputs (VaR, CVaR, predictions, signals, etc.)
        self.logs = []       # Agent-level audit log

    # ---------------------------------------------------------
    # Logging helpers
    # ---------------------------------------------------------
    def log(self, agent: str, message: str):
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{ts}] [{agent}] {message}"
        print(entry)
        self.logs.append(entry)

    # ---------------------------------------------------------
    # Convenient state inspection
    # ---------------------------------------------------------
    def summary(self):
        print("\n===== MAS STATE SUMMARY =====")
        print("Data Keys:", list(self.data.keys()))
        print("Result Keys:", list(self.results.keys()))
        print("Log entries:", len(self.logs))
        print("=============================\n")
