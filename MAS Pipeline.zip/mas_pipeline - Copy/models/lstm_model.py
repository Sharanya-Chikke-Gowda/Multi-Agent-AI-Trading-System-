# models/lstm_model.py

import torch
import torch.nn as nn


class LSTMPredictor(nn.Module):
    """
    Simple but robust LSTM predictor for 5-day forward return.
    Compatible with PredictionAgent.
    """

    def __init__(self, input_size, hidden_size=64, num_layers=2, dropout=0.1):
        super().__init__()

        self.input_size = input_size

        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            dropout=dropout,
            batch_first=True
        )

        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x):
        """
        x.shape = (batch, window, input_size)
        """
        out, _ = self.lstm(x)               # → (batch, window, hidden)
        out = out[:, -1, :]                 # → take last time step
        out = self.fc(out)                  # → regression output
        return out
