# agents/backtester_agent.py

import pandas as pd
import numpy as np
from core.logger_sqlite import sqlite_logger


def BacktesterAgent(state, start_equity=100000):
    agent = "BacktesterAgent"
    state.log(agent, "Running backtest...")

    # -------------------------------
    # Extract data
    # -------------------------------
    df = state.data["prices"].copy()

    # price & daily returns
    if "price" in df.columns:
        price = df["price"]
    elif "Adj Close" in df.columns:
        price = df["Adj Close"]
    else:
        price = df.iloc[:, 0]

    daily_ret = price.pct_change().fillna(0)

    # -------------------------------
    # Get signal + position size
    # -------------------------------
    signal = state.results.get("signal", "HOLD")
    size = state.results.get("position_size", 0.0)

    state.log(agent, f"Final decision = {signal}, size={size}")

    # -------------------------------
    # Build daily position series
    # -------------------------------
    # One-shot LSTM signal applied to full backtest
    if signal == "BUY":
        pos = np.ones(len(daily_ret)) * size        # long
    elif signal == "SELL":
        pos = np.ones(len(daily_ret)) * (-size)     # short
    else:
        pos = np.zeros(len(daily_ret))              # no trade

    pos = pd.Series(pos, index=daily_ret.index)

    # -------------------------------
    # PnL Calculation
    # -------------------------------
    pnl = pos * daily_ret
    equity = start_equity * (1 + pnl).cumprod()

    # store for report
    state.results["equity_curve"] = equity.values.tolist()
    state.results["final_equity"] = float(equity.iloc[-1])
    state.results["daily_pnl"] = pnl.values.tolist()

    # audit log
    state.log(agent, f"Final equity: {equity.iloc[-1]:,.2f}")

    sqlite_logger.metric("final_equity", float(equity.iloc[-1]))
    sqlite_logger.metric("trade_signal", signal)

    return state
