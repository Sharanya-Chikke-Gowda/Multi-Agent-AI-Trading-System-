# agents/risk_agent.py
"""
Robust RiskAgent (drop-in replacement).

Features:
- Handles single-asset and multi-asset correctly
- Aligns price series, computes daily simple returns safely
- Converts scalar/1D covariance -> proper (N x N) matrix
- Supports GBM, Student-t and historical (block) bootstrap simulation
- Calculates portfolio-level P&L returns and computes VaR/CVaR
- More diagnostic logging to help debug inflated returns
"""

import numpy as np
from typing import List, Optional
from core.logger_sqlite import sqlite_logger
from utils.mc_utils import (
    shrinkage_covariance,
    gbm_batch_simulate,
    student_t_shocks,
    block_bootstrap_returns
)


def RiskAgent(
    state,
    assets: Optional[List[str]] = None,
    window: int = 252,
    horizon_days: int = 5,
    mc_sims: int = 20000,
    var_alpha: float = 0.05,
    method: str = "gbm_mv",      # "gbm_mv" | "studentt_mv" | "bootstrap_block" | "historical"
    student_t_df: float = 10.0,
    batch_size: int = 2000,
    weights: Optional[List[float]] = None,
    relax_var_threshold: float = -0.12,   # VaR threshold (default more permissive)
    relax_cvar_threshold: float = -0.18,
    use_portfolio_pnl: bool = True,
):
    agent = "RiskAgent"
    state.log(agent, f"Start RiskAgent(method={method}, sims={mc_sims}, horizon={horizon_days})")

    # --- Load / align price series ---
    prices_multi = state.data.get("prices_multi")
    prices_primary = state.data.get("prices")

    if assets and prices_multi:
        # Try to align requested assets; keep only those present
        dfs = {}
        for t in assets:
            if t in prices_multi:
                dfs[t] = prices_multi[t][["price"]].rename(columns={"price": t})
            else:
                state.log(agent, f"Requested asset {t} not in prices_multi; skipping.")
        if len(dfs) == 0:
            # fallback to primary
            state.log(agent, "No requested assets available in prices_multi -> using primary prices")
            prices_df = prices_primary[["price"]].rename(columns={"price": "ASSET"})
        else:
            # join on inner intersection to avoid NaN inflation
            import pandas as pd
            prices_df = pd.concat(dfs.values(), axis=1, join="inner")
    else:
        # Use primary single-asset dataframe
        if prices_primary is None:
            raise RuntimeError("RiskAgent: no price data found in state.data['prices']")
        # Ensure price column
        col = "price" if "price" in prices_primary.columns else ("Adj Close" if "Adj Close" in prices_primary.columns else prices_primary.columns[0])
        prices_df = prices_primary[[col]].rename(columns={col: "ASSET"})

    # Ensure we have enough data
    if len(prices_df) < max(window, horizon_days) + 2:
        state.log(agent, f"Not enough history ({len(prices_df)} rows) for window={window}. Aborting RiskAgent.")
        # mark safe defaults
        state.results["VaR_5d"] = 0.0
        state.results["CVaR_5d"] = 0.0
        state.results["risk_flag"] = False
        return

    # compute daily simple returns aligned
    returns_df = prices_df.pct_change().dropna()
    # Use the last 'window' rows for moment estimation
    returns_for_moments = returns_df.tail(window)

    # Debug logging: basic moments (per-asset)
    mu_daily = returns_for_moments.mean().values  # shape (N,)
    sigma_daily = returns_for_moments.std(ddof=1).values
    state.log(agent, f"Mu (daily) per asset: {mu_daily}")
    state.log(agent, f"Sigma (daily) per asset: {sigma_daily}")

    # Build returns matrix (T, N)
    returns_mat = returns_for_moments.values
    T, N = returns_mat.shape
    state.log(agent, f"Using T={T} days, N={N} assets for covariance")

    # Estimate covariance (daily). Handle scalar / 1D -> convert to NxN
    raw_cov = np.cov(returns_mat.T, ddof=1)
    if np.isscalar(raw_cov):
        raw_cov = np.array([[float(raw_cov)]])
    elif raw_cov.ndim == 1:
        raw_cov = np.diag(raw_cov)

    cov_daily = shrinkage_covariance(raw_cov, shrink=0.1)

    # portfolio weights
    if weights is None:
        weights = np.ones(N) / N
    weights = np.asarray(weights, dtype=float)
    if weights.size != N:
        raise ValueError("RiskAgent: weights length must equal number of assets")

    # --- Monte Carlo / Historical simulation ---
    rng = np.random.default_rng()
    port_cum = np.empty(mc_sims, dtype=float)
    sims_done = 0
    sample_paths = []

    # Option: historical "non-parametric" simulation (bootstrap of horizon-day returns)
    if method == "historical":
        # build horizon-day cumulative returns from historical data
        # slide a window of length horizon_days and compute cumulative simple return
        hist_cum = []
        arr = returns_df.values
        for i in range(0, len(arr) - horizon_days):
            seq = arr[i:i + horizon_days]  # shape (horizon, N)
            cum = np.prod(1 + seq, axis=0) - 1.0
            hist_cum.append(cum)
        hist_cum = np.vstack(hist_cum)  # (M, N)
        # sample with replacement
        idx = rng.integers(0, hist_cum.shape[0], size=mc_sims)
        sampled = hist_cum[idx]  # (mc_sims, N)
        port_cum = sampled @ weights
        # store a few sample paths
        for i in range(min(10, len(sampled))):
            sample_paths.append({prices_df.columns[j]: float(sampled[i, j]) for j in range(N)})
    else:
        # parametric / bootstrap generation in batches
        while sims_done < mc_sims:
            b = min(batch_size, mc_sims - sims_done)

            if method == "gbm_mv":
                cum_simple = gbm_batch_simulate(b, horizon_days, mu_daily, cov_daily, rng=rng)
            elif method == "studentt_mv":
                shocks = student_t_shocks(b, horizon_days, N, df=student_t_df, cov=cov_daily, rng=rng)
                # convert to cumulative simple returns using GBM-like drift
                drift = (mu_daily - 0.5 * np.diag(cov_daily))
                cum_simple = np.exp(np.sum(shocks + drift[np.newaxis, np.newaxis, :], axis=1)) - 1.0
            elif method == "bootstrap_block":
                cum_simple = block_bootstrap_returns(returns_mat, horizon_days, b, block_size=5, rng=rng)
            else:
                raise ValueError(f"RiskAgent: unknown method {method}")

            port_cum[sims_done:sims_done + b] = (cum_simple @ weights)
            for i in range(min(5, b)):
                sample_paths.append({prices_df.columns[j]: float(cum_simple[i, j]) for j in range(N)})
            sims_done += b

    # --- compute risk metrics on portfolio cumulative returns ---
    alpha_pct = var_alpha * 100.0
    VaR = float(np.percentile(port_cum, alpha_pct))
    tail = port_cum[port_cum <= VaR]
    CVaR = float(np.mean(tail)) if tail.size > 0 else float(VaR)

    # compute additional percentiles for diagnostics
    p10, p25, p50, p75, p90 = [float(np.percentile(port_cum, p)) for p in (10, 25, 50, 75, 90)]

    # Decide risk_flag using relaxed configured thresholds
    risk_flag = (VaR < relax_var_threshold) or (CVaR < relax_cvar_threshold)

    # Save results into state
    state.results["VaR_5d"] = VaR
    state.results["CVaR_5d"] = CVaR
    state.results["p10"] = p10
    state.results["p25"] = p25
    state.results["p50"] = p50
    state.results["p75"] = p75
    state.results["p90"] = p90
    state.results["risk_flag"] = bool(risk_flag)
    state.results["mc_sample_paths"] = sample_paths[:20]
    state.results["risk_summary"] = {
        "assets": list(prices_df.columns),
        "VaR": VaR,
        "CVaR": CVaR,
        "percentiles": {"p10": p10, "p50": p50, "p90": p90},
        "n_days_used": int(T),
        "mu_daily": mu_daily.tolist(),
        "sigma_daily": sigma_daily.tolist()
    }

    # sqlite log
    sqlite_logger.metric("VaR_5d", VaR)
    sqlite_logger.metric("CVaR_5d", CVaR)
    sqlite_logger.mc(f"method={method}", mc_sims, horizon_days, {"VaR": VaR, "CVaR": CVaR})

    # Debug print summary
    state.log(agent, f"MC complete: VaR={VaR:.4f}, CVaR={CVaR:.4f}, p10={p10:.4f}, risk_flag={risk_flag}")
