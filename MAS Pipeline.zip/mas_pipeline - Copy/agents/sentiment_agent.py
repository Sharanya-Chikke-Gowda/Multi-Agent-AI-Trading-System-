def SentimentAgent(state):
    df=state.data['prices']
    df['sentiment']=df['return'].rolling(5).mean().fillna(0)
    df['sent_mom']=df['sentiment'].diff().fillna(0)
    state.data['prices']=df
    state.log("SentimentAgent","Sentiment added.")
