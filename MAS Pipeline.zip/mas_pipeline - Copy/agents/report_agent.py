# agents/report_agent.py
import os
import io
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from datetime import datetime
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, Table, TableStyle
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors

from core.logger_sqlite import sqlite_logger

# -------------------------
# Helper metrics functions
# -------------------------
def annualize_return(daily_ret):
    # daily_ret: pandas Series
    avg = daily_ret.mean()
    return (1 + avg) ** 252 - 1

def annualize_vol(daily_ret):
    return daily_ret.std(ddof=1) * math.sqrt(252)

def sharpe_ratio(daily_ret, rf=0.0):
    ann_ret = annualize_return(daily_ret)
    ann_vol = annualize_vol(daily_ret)
    if ann_vol == 0:
        return 0.0
    return (ann_ret - rf) / ann_vol

def max_drawdown(equity_curve):
    # equity_curve: numpy array or pandas Series of cumulative equity values
    eq = np.asarray(equity_curve)
    roll_max = np.maximum.accumulate(eq)
    drawdowns = (eq - roll_max) / roll_max
    return float(drawdowns.min())

def equity_from_returns(daily_ret, start_equity=100000.0):
    # daily_ret: pandas Series
    cum = (1 + daily_ret).cumprod()
    return start_equity * cum

def simple_linear_forecast(price_series):
    # simple linear trend forecast normalized
    y = np.asarray(price_series)
    if len(y) < 2:
        return 0.0
    x = np.arange(len(y))
    coef = np.polyfit(x, y, 1)[0]
    return coef / max(y[-1], 1.0)

# -------------------------
# Main ReportAgent
# -------------------------
def ReportAgent(state):
    agent = "ReportAgent"
    state.log(agent, "Generating benchmark PDF with metrics & charts...")

    os.makedirs("reports", exist_ok=True)

    # Load price series
    prices_df = state.data.get("prices")
    if prices_df is None:
        state.log(agent, "No price data available for report.")
        return

    # canonical price column
    if "price" in prices_df.columns:
        price_series = prices_df["price"].copy()
    elif "Adj Close" in prices_df.columns:
        price_series = prices_df["Adj Close"].copy()
    else:
        price_series = prices_df.iloc[:, 0].copy()  # fallback to first column

    price_series = price_series.sort_index()
    daily_ret = price_series.pct_change().fillna(0)

    start_equity = 100000.0
    rf = 0.0  # risk-free for Sharpe (annual)

    # ---------- Build Baselines / Signals ----------
    results = {}

    # 1) Buy & Hold
    bh_daily = daily_ret.copy()
    bh_equity = equity_from_returns(bh_daily, start_equity)
    results["Buy & Hold"] = {"daily_ret": bh_daily, "equity": bh_equity}

    # 2) Risk-Parity (single asset -> same as buy & hold)
    rp_daily = bh_daily.copy()
    rp_equity = bh_equity.copy()
    results["Risk-Parity"] = {"daily_ret": rp_daily, "equity": rp_equity}

    # 3) Single-Agent LSTM (constant signal derived from predicted_return_5d)
    pred = float(state.results.get("predicted_return_5d", 0.0))
    sig_lstm = 1 if pred > 0 else -1 if pred < 0 else 0
    lstm_daily = sig_lstm * daily_ret
    lstm_equity = equity_from_returns(lstm_daily, start_equity)
    results["Single-Agent LSTM"] = {"daily_ret": lstm_daily, "equity": lstm_equity}

    # 4) Sentiment-Only (use 'sent_mom' column if present)
    if "sent_mom" in prices_df.columns:
        sent_mom = prices_df["sent_mom"].fillna(0)
        # signal each day: +1 if momentum > 0, -1 if < 0, 0 if 0
        sent_signal = sent_mom.apply(lambda x: 1 if x > 0 else (-1 if x < 0 else 0))
        sentiment_daily = sent_signal.shift(1).fillna(0) * daily_ret  # use prior-day signal
        sentiment_equity = equity_from_returns(sentiment_daily, start_equity)
        results["Sentiment-Only"] = {"daily_ret": sentiment_daily, "equity": sentiment_equity}
    else:
        # if no sentiment available, put N/A
        state.log(agent, "No sentiment columns found; Sentiment-Only baseline skipped.")
        results["Sentiment-Only"] = None

    # 5) No-Risk MAS (ignore risk_flag, use LSTM signal)
    sig_norisk = sig_lstm
    norisk_daily = sig_norisk * daily_ret
    norisk_equity = equity_from_returns(norisk_daily, start_equity)
    results["No-Risk MAS"] = {"daily_ret": norisk_daily, "equity": norisk_equity}

    # Ablations:
    # A) No Sentiment (use LSTM prediction but with sentiment features dropped)
    no_sent_daily = sig_lstm * daily_ret
    no_sent_equity = equity_from_returns(no_sent_daily, start_equity)
    results["Ablation: No Sentiment"] = {"daily_ret": no_sent_daily, "equity": no_sent_equity}

    # B) No Monte Carlo -> same as No-Risk MAS here
    results["Ablation: No Monte Carlo"] = results["No-Risk MAS"]

    # C) Linear model baseline
    lin_pred = simple_linear_forecast(price_series)
    sig_lin = 1 if lin_pred > 0 else -1 if lin_pred < 0 else 0
    lin_daily = sig_lin * daily_ret
    lin_equity = equity_from_returns(lin_daily, start_equity)
    results["Ablation: Linear Model"] = {"daily_ret": lin_daily, "equity": lin_equity}

    # Full MAS pipeline equity (final_equity from backtester if present)
    mas_final = float(state.results.get("final_equity", start_equity))
    # we also have the equity curve in state.results if backtester stored it, else use final only
    mas_equity_curve = state.results.get("equity_curve", None)
    if mas_equity_curve is not None:
        mas_equity_series = pd.Series(mas_equity_curve, index=price_series.index[-len(mas_equity_curve):])
        results["Full MAS Pipeline"] = {"daily_ret": (mas_equity_series.pct_change().fillna(0)), "equity": mas_equity_series}
    else:
        # fallback: flat equity (if no detailed backtest)
        results["Full MAS Pipeline"] = {"daily_ret": pd.Series(np.zeros(len(daily_ret)), index=daily_ret.index), "equity": pd.Series(np.ones(len(daily_ret))*mas_final, index=daily_ret.index)}

    # -------------------------
    # Compute metrics and plots
    # -------------------------
    metrics_rows = []
    chart_paths = []
    for name, data in results.items():
        if data is None:
            metrics_rows.append([name, "N/A", "N/A", "N/A", "N/A"])
            chart_paths.append(None)
            continue

        dr = data["daily_ret"]
        eq = data["equity"]

        # if equity is pandas Series, ensure numeric values
        if isinstance(eq, (pd.Series, pd.DataFrame)):
            eq_vals = np.asarray(eq).astype(float)
        else:
            eq_vals = np.asarray(eq).astype(float)

        total_return = float(eq_vals[-1] / start_equity - 1.0) if len(eq_vals) > 0 else 0.0
        ann_ret = annualize_return(dr)
        ann_vol = annualize_vol(dr)
        sr = sharpe_ratio(dr, rf=rf)
        mdd = max_drawdown(eq_vals)

        metrics_rows.append([
            name,
            f"{total_return*100: .2f}%",
            f"{ann_ret*100: .2f}%",
            f"{ann_vol*100: .2f}%",
            f"{sr: .3f}",
            f"{mdd*100: .2f}%"
        ])

        # Plot equity curve
        plt.figure(figsize=(8,4))
        if isinstance(eq, (pd.Series, pd.DataFrame)):
            eq.plot()
        else:
            plt.plot(eq_vals)
        plt.title(f"Equity Curve — {name}")
        plt.xlabel("Time")
        plt.ylabel("Equity")
        plt.grid(alpha=0.3)

        img_path = f"reports/{name.replace(' ', '_').replace(':','')}_equity.png"
        plt.tight_layout()
        plt.savefig(img_path)
        plt.close()

        chart_paths.append(img_path)

    # -------------------------
    # Build PDF with metrics table + charts
    # -------------------------
    pdf_path = "reports/mas_benchmarks_metrics.pdf"
    doc = SimpleDocTemplate(pdf_path, pagesize=A4)
    styles = getSampleStyleSheet()
    elems = []

    elems.append(Paragraph("<b>MAS Benchmarks & Ablations Report</b>", styles["Title"]))
    elems.append(Paragraph(f"Generated: {datetime.utcnow().isoformat()} UTC", styles["Normal"]))
    elems.append(Spacer(1,12))

    # Metrics table header
    table_data = [["Strategy","Total Return","Annual Return","Annual Vol","Sharpe (rf=0)","Max Drawdown"]]
    for r in metrics_rows:
        table_data.append(r)

    table = Table(table_data, colWidths=[160,80,80,80,80,80])
    table.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0), colors.grey),
        ("TEXTCOLOR",(0,0),(-1,0), colors.white),
        ("ALIGN",(0,0),(-1,-1),"CENTER"),
        ("GRID",(0,0),(-1,-1),0.5,colors.black),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
    ]))
    elems.append(table)
    elems.append(Spacer(1,16))

    # Add each chart on its own page with caption
    for i, (name, data) in enumerate(results.items()):
        path = chart_paths[i]
        elems.append(Paragraph(f"<b>{name}</b>", styles["Heading2"]))
        elems.append(Spacer(1,6))
        if path and os.path.exists(path):
            # Resize to fit page
            elems.append(Image(path, width=480, height=240))
        else:
            elems.append(Paragraph("No chart available.", styles["Normal"]))
        elems.append(PageBreak())

    doc.build(elems)

    state.log(agent, f"Saved benchmarks + metrics PDF to {pdf_path}")
    sqlite_logger.metric("benchmarks_report", 1)

