# agents/portfolio_agent.py

def PortfolioAgent(state):
    agent = "PortfolioAgent"

    pred = float(state.results.get("predicted_return_5d", 0))
    risk_flag = state.results.get("risk_flag", True)

    threshold = 0.01        # 1% required confidence
    leverage_factor = 12.0  # scaling factor for exposure

    # ★ If risk is too high → NO TRADE
    if risk_flag:
        state.results["signal"] = "NO_TRADE"
        state.results["position_size"] = 0.0
        state.log(agent, "NO_TRADE (risk gate)")
        return

    # ★ LONG
    if pred > threshold:
        size = min(1.0, pred * leverage_factor)
        state.results["signal"] = "BUY"
        state.results["position_size"] = round(size, 4)
        state.log(agent, f"BUY size={size:.4f}")
        return

    # ★ SHORT
    if pred < -threshold:
        size = min(1.0, abs(pred) * leverage_factor)
        state.results["signal"] = "SELL"
        state.results["position_size"] = round(size, 4)
        state.log(agent, f"SELL size={size:.4f}")
        return

    # ★ HOLD
    state.results["signal"] = "HOLD"
    state.results["position_size"] = 0.0
    state.log(agent, "HOLD (signal too weak)")
