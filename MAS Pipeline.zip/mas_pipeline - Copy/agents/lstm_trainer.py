import torch
import torch.nn as nn
from models.lstm_model import LSTMPredictor
from core.logger_sqlite import sqlite_logger


def train_lstm(state, epochs=8, window=60, lr=1e-3, save="lstm_model.pth"):
    agent = "LSTM_Trainer"

    df = state.data["prices"]

    # MUST match DataAgent + PredictionAgent
    FEATS = ["return", "SMA20", "vol20", "sentiment", "sent_mom", "price"]
    input_dim = len(FEATS)

    # Extract feature matrix
    data = df[FEATS].values.astype("float32")

    # Target = 5-day forward return
    targets = df["return"].shift(-5).fillna(0).values.astype("float32")

    X, y = [], []

    # Build rolling windows
    for i in range(len(data) - window - 5):
        X.append(data[i:i + window])
        y.append(targets[i])

    if len(X) == 0:
        state.log(agent, "Not enough data to train LSTM.")
        return LSTMPredictor(input_dim=input_dim)

    # Convert to tensors
    X = torch.tensor(X)
    y = torch.tensor(y).unsqueeze(1)

    # Build model
    model = LSTMPredictor(input_dim=input_dim)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()

    # Training loop
    for ep in range(epochs):
        optimizer.zero_grad()
        pred = model(X)
        loss = loss_fn(pred, y)
        loss.backward()
        optimizer.step()

        # log loss into SQLite
        sqlite_logger.metric("lstm_loss", float(loss.item()))

        state.log(agent, f"Epoch {ep+1}/{epochs}, loss={loss.item():.6f}")

    # Save trained model
    torch.save(model.state_dict(), save)
    state.log(agent, f"LSTM saved: {save}")

    return model
