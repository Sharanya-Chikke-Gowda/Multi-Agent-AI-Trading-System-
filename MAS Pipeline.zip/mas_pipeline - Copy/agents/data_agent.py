# agents/data_agent.py

import yfinance as yf
import pandas as pd
import numpy as np

def DataAgent(
    state,
    tickers,
    context_tickers=None,
    start="2010-01-01",
    end=None
):
    """
    Loads main asset + context tickers (SPY, QQQ, VIX, TNX)
    Cleans data
    Computes features
    Stores into state.data as:
        - prices
        - prices_multi (dict for multi-asset)
        - indicators
    """

    agent = "DataAgent"
    state.log(agent, f"Loading price data for {tickers}...")

    if context_tickers is None:
        context_tickers = []

    all_tickers = list(tickers) + list(context_tickers)

    prices_multi = {}

    for t in all_tickers:
        df = yf.download(t, start=start, end=end, progress=False)

        if df is None or df.empty:
            state.log(agent, f"Failed to load ticker: {t}")
            continue

        # Normalize price column
        if "Adj Close" in df.columns:
            df["price"] = df["Adj Close"]
        else:
            df["price"] = df["Close"]

        df["return"] = df["price"].pct_change().fillna(0)

        # Simple features
        df["SMA20"] = df["price"].rolling(20).mean()
        df["SMA50"] = df["price"].rolling(50).mean()
        df["vol20"] = df["return"].rolling(20).std()
        df["vol50"] = df["return"].rolling(50).std()

        df = df.dropna().copy()

        prices_multi[t] = df

    # Store full multi-asset dictionary
    state.data["prices_multi"] = prices_multi

    # Store primary ticker data in state.data["prices"]
    primary = tickers[0]
    if primary not in prices_multi:
        raise RuntimeError(f"Primary ticker {primary} missing from loaded data!")

    state.data["prices"] = prices_multi[primary]

    # Attach sentiment placeholder (actual sentiment is added later)
    state.data["sentiment"] = None

    state.log(agent, f"DataAgent completed. Loaded {len(prices_multi)} tickers.")
