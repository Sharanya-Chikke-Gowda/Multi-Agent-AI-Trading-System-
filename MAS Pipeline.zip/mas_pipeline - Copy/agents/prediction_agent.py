# agents/prediction_agent.py

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from models.lstm_model import LSTMPredictor
from core.logger_sqlite import sqlite_logger


# ============================
# LSTM Training Helper
# ============================
def train_lstm(model, X, y, epochs=25, lr=0.001):
    device = "cpu"
    model.to(device)
    optim = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()

    X_t = torch.tensor(X, dtype=torch.float32).to(device)
    y_t = torch.tensor(y, dtype=torch.float32).to(device)

    for _ in range(epochs):
        optim.zero_grad()
        pred = model(X_t).squeeze()
        loss = loss_fn(pred, y_t)
        loss.backward()
        optim.step()


# ============================
# MAIN AGENT
# ============================
def PredictionAgent(state, window=60, retrain=True):
    agent = "PredictionAgent"
    state.log(agent, "Running PredictionAgent (LSTM)")

    df = state.data["prices"]

    # -------------------------------
    # REQUIRED FEATURES
    # -------------------------------
    FEATS = ["return", "SMA20", "SMA50", "vol20", "vol50"]

    # Safety check
    missing = [f for f in FEATS if f not in df.columns]
    if len(missing) > 0:
        raise RuntimeError(f"Missing features in DataAgent output: {missing}")

    # -------------------------------
    # Build windowed dataset
    # -------------------------------
    X_list, y_list = [], []

    returns = df["return"].values
    feat_mat = df[FEATS].values

    for i in range(window, len(df) - 5):  # 5-day forward prediction
        X_list.append(feat_mat[i - window:i])
        future_ret = (df["price"].iloc[i + 5] / df["price"].iloc[i]) - 1
        y_list.append(future_ret)

    X = np.array(X_list, dtype=np.float32)
    y = np.array(y_list, dtype=np.float32)

    # -------------------------------
    # Initialize model
    # -------------------------------
    model = LSTMPredictor(input_size=len(FEATS))

    # -------------------------------
    # Retrain or load old model
    # -------------------------------
    import os

    if retrain or not os.path.exists("lstm_model.pth"):
        state.log(agent, "Training LSTM model...")
        train_lstm(model, X, y)
        torch.save(model.state_dict(), "lstm_model.pth")
        state.log(agent, "Training complete. Model saved.")
    else:
        state.log(agent, "Loading saved LSTM model...")
        model.load_state_dict(torch.load("lstm_model.pth", map_location="cpu"))

    # -------------------------------
    # Predict latest point
    # -------------------------------
    latest_window = feat_mat[-window:].astype(np.float32)
    latest_window = torch.tensor(latest_window).unsqueeze(0)

    pred = model(latest_window).item()

    state.results["predicted_return_5d"] = float(pred)
    state.log(agent, f"Predicted 5d return: {pred:.5f}")

    sqlite_logger.metric("predicted_return_5d", float(pred))
